<?php

/* 
 * This file is part of is free software.
 */
/*
    Created on : 8 дек. 2025 г., 10:44:35
    Author     : Dmitrij Nedeljković https://dmitrydevelopment.com/
*/
// config/config.php

// Параметры подключения к базе данных.
define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_USER', 'kostyasw_dash');
define('DB_PASSWORD', 'BVKV!4Iy');
define('DB_NAME', 'kostyasw_dash');

// Общие настройки приложения.
define('APP_ENV', 'local');         // local или production

// Базовый путь проекта
define('APP_BASE_PATH', dirname(__DIR__));